#操作excel
require 'win32ole'
require 'Set'
# Default code, use or delete...
mod = Sketchup.active_model # Open model
ent = mod.entities # All entities in model
sel = mod.selection # Current selection
#获取顶点的拓扑关系（点与点的关系）
def next_of(array, element)
  idx = array.index(element)
  return nil unless idx && idx + 1 < array.size
  array[idx + 1]
end
def get_related_vertices(vertex)
  related = Set.new
  vertex.edges.each do |edge|
    edge.vertices.each do |v|
      related.add(v) unless v == vertex
    end
  end
  related.to_a
end

# 获取一个三角面中以 vex1 为中点的逆时针顶点顺序
def get_ordered_vertices(vex1, face1)
  vertices = face1.vertices
  return vertices unless vertices.size == 3  # 确保是三角面

  # 获取 vex1 在三角面中的左右顶点（不是 vex1 的那两个）
  other_vertices = vertices - [vex1]
  vex0, vex2 = other_vertices[0], other_vertices[1]

  # 获取三点坐标
  p0 = vex0.position
  p1 = vex1.position
  p2 = vex2.position

  # 构建向量
  v1 = p0.vector_to(p1) # vex0 -> vex1
  v2 = p1.vector_to(p2) # vex1 -> vex2

  # 叉积判断方向，和面的法向量比较
  cross = v1 * v2
  face_normal = face1.normal

  # 如果叉积方向与面法向量一致，说明顺序是逆时针
  if cross.samedirection?(face_normal)
    [vex0, vex1, vex2]
  else
    [vex2, vex1, vex0]
  end
end


#已知三角形一条边，获取对应的第三个顶点
def get_another_vex(vex1, vex2, face1)
  face1_vex_array = face1.vertices
  face1_vex_array.find { |vex| vex != vex1 && vex != vex2 }
end

# 创建插件，实现命令
toolbar_transform = UI::Toolbar.new 'triangle3'
# 创建命令（主函数）调用各函数
plugin = UI::Command.new('print_triangle') {
  mod = Sketchup.active_model
  ent = mod.entities
  sel = mod.selection

  group_array = ent.grep(Sketchup::Group)
  face_array = ent.grep(Sketchup::Face)
  all_face_array = []
  model_vertices_array = []
  group_array.each do |one_group|
    one_group_entities = one_group.entities
    one_group_face = one_group_entities.grep(Sketchup::Face)
    one_group_face.each { |one_face| all_face_array << one_face }
  end

  if face_array.any?
    face_array.each { |one_face| all_face_array << one_face }
  else
    UI.messagebox "no independent faces or edges"
  end

  model_faces_array = all_face_array.uniq
  #遍历组中的所有面
  if group_array.length>0
    UI.messagebox "the number of group is:"+group_array.length.to_s
    group_array.each do |one_group|      
      one_group_entities=one_group.entities
      one_group_face=one_group_entities.grep(Sketchup::Face)
      one_group_face.each do |one_face|
        vt=one_face.vertices
        for i in (0..vt.length-1)
          group_vertices_array << vt[i]
        end
      end
      group_vertices_array=group_vertices_array.uniq
      model_vertices_array << group_vertices_array
    end       
  else
    UI.messagebox "the number of group is 0"
  end
  
  #遍历非组面
  face_vertices_array=Array.new()
  if face_array.length>0
    face_array.each do |one_face|
      vtarr=one_face.vertices
      for i in (0..vtarr.length-1)
        face_vertices_array << vtarr[i]
      end
    end 
    face_vertices_array=face_vertices_array.uniq
    
    for i in (0..face_vertices_array.length-1)
      model_vertices_array << face_vertices_array[i]
    end 
  else
    UI.messagebox "no independent faces or edges"
  end
  #模型中的全部顶点
  model_vertices_array = model_vertices_array.uniq
  traversed_faces_array = []
  traversed_vertices_array = []
  
  if sel.grep(Sketchup::Face)[0]
    start_triangle = sel.grep(Sketchup::Face)[0]
  else
    start_triangle = model_faces_array[0]
  end
  triangle_vex_array = start_triangle.vertices

  fvex0, fvex1, fvex2 = get_ordered_vertices(triangle_vex_array[0], start_triangle)

  traversed_vertices_array.push(fvex0, fvex1, fvex2)
  traversed_faces_array << start_triangle

  now_face = start_triangle
  now_face.material = Sketchup::Color.new(255, 0, 0)

  loop_count = 0
  while traversed_vertices_array.length < model_vertices_array.length
    loop_count += 1
    break if loop_count > model_vertices_array.length * 10  # 防止死循环
    # 修复逻辑：
    now_edge = fvex2.common_edge(fvex0)
    if now_edge.nil?
      puts "⚠️ 当前 fvex2 和 fvex0 之间没有边，尝试重选起点..."

      found_valid = false
      traversed_vertices_array.each_with_index do |vex, i|
        next_vex = traversed_vertices_array[i + 1]
        break if next_vex.nil?
        test_edge = vex.common_edge(next_vex)
        if test_edge && test_edge.faces.any? { |f| !traversed_faces_array.include?(f) }
          fvex0 = vex
          fvex2 = next_vex
          now_face = (test_edge.faces - traversed_faces_array)[0]
          now_face.material = Sketchup::Color.new(166, 100, 150)
          found_valid = true
          break
        end
      end

      unless found_valid
        puts "🚫 未找到新的合法边可继续遍历，遍历完成或中断。"
        break
      end
    else
      now_face = (now_edge.faces - [now_face])[0]
    end
    traversed_faces_array << now_face
    another_vex = get_another_vex(fvex2,fvex0,now_face)
    if traversed_vertices_array.include?(another_vex)
      vertices1 = get_related_vertices(fvex0)
      if vertices1.all? { |vex| traversed_vertices_array.include?(vex)}
        puts "该点遍历已完成，遍历点为下一点"
        fvex1 = fvex0
        fvex0 = next_of(traversed_vertices_array,fvex0)
      else
        fvex1 = fvex2
        fvex2 = another_vex
      end
    else
      traversed_vertices_array << another_vex
      fvex1 = fvex2
      fvex2 = another_vex
      now_face.material = Sketchup::Color.new(66, 216, 195)
    end
  end

  # 获取各个顶点所对应的标识符
  all_mark_array = traversed_vertices_array.map { |vex| get_related_vertices(vex).length }

  # 数据存储
  traversed_point_array = traversed_vertices_array.map(&:position)
  puts traversed_point_array
  save_path = UI.savepanel("选择保存位置", "C:\\Users\\SZU\\Desktop", "output.xlsx")
  if save_path.nil?
    UI.messagebox "未选择保存路径，导出已取消。"
    return
  end
  myexcel1 = WIN32OLE.new("excel.application")
  myexcel1.visible = false
  mywbk1 = myexcel1.Workbooks.Add()
  mywst1 = mywbk1.Worksheets(1)
  arr = ['No.', 'Lontitude', 'Latitude', 'Height', 'Mark']
  mywst1.Range('A1:E1').value = arr

  traversed_vertices_array.each_with_index do |vex, num|
    mywst1.Range("A#{num+2}").value = num + 1
    mywst1.Range("B#{num+2}").value = traversed_point_array[num].x.to_m
    mywst1.Range("C#{num+2}").value = traversed_point_array[num].y.to_m
    mywst1.Range("D#{num+2}").value = traversed_point_array[num].z.to_m
    mywst1.Range("E#{num+2}").value = all_mark_array[num]
  end

  mywbk1.SaveAs save_path
  mywbk1.Close
  UI.messagebox "遍历完成! 文件已保存到: #{save_path}"
  
  puts "模型中顶点数量：#{model_vertices_array.length}"
  puts "遍历顶点数量：#{traversed_point_array.length}"
}

plugin.large_icon = "large.png"
plugin.small_icon = "small.png"
plugin.tooltip = "vertices and faces!"
plugin.status_bar_text = "print triangle mesh information!"
plugin.menu_text = "Triangle3"

toolbar_transform = toolbar_transform.add_item plugin
toolbar_transform.show
