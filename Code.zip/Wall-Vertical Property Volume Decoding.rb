require 'win32ole'
# Default code, use or delete...
mod = Sketchup.active_model # Open model
ent = mod.entities # All entities in model
sel = mod.selection # Current selection

def model_center(entities)
  bounding_box = entities.bounds
  center_point = bounding_box.center
  return center_point
end
def unit_vector(vector)
  length = vector.length
  return Geom::Vector3d.new(vector.x / length, vector.y / length, vector.z / length)
end
def collinear?(p1,p2,p3)
  v1 = Geom::Vector3d.new(p2.x - p1.x,p2.y - p1.y, p2.z - p1.z)
  v2 = Geom::Vector3d.new(p3.x - p2.x,p3.y - p2.y, p3.z - p2.z)
  unit_v1 = unit_vector(v1)
  unit_v2 = unit_vector(v2)
  dot_product = unit_v1.dot(unit_v2)
  dot_product.abs > 0.99
end
def get_related_vertices(vex1)
  related_vertices_array = Array.new()
  edges_array = vex1.edges
  edges_array.each do |one_edge|
    other_vertex = one_edge.other_vertex(vex1)
    related_vertices_array << other_vertex
  end
  related_vertices_array.uniq
  return related_vertices_array
end

def get_transverse_vertices(vex1)
  vex1_array = get_related_vertices(vex1)
  vex1_new_array = Array.new()
  vex1_array.each do |vertex|
    point1 = vex1.position
    point2 = vertex.position
    next if point1.x == point2.x && point1.y == point2.y
    vex1_new_array << vertex
  end
  return vex1_new_array
end

def get_vertical_vertices(vex1)
  tr = 0
  found_vertex = nil  # 使用明确的nil作为找不到顶点的标志
  point1 = vex1.position
  related_vertices = get_related_vertices(vex1)
  related_vertices.each do |vertex|
    point2 = vertex.position
    if (point1.x - point2.x).abs < 0.001 && (point1.y - point2.y).abs < 0.001 && point1 != point2  # 使用误差范围比较
      tr = 1
      found_vertex = vertex
      break
    end
  end
  return tr, found_vertex  # 返回找到的顶点，如果没有找到则为nil
end

def iterative_transverse_face(vex1_first)
  stack = [vex1_first]
  every_traverse_array = []
  
  while !stack.empty?
    current = stack.pop
    every_traverse_array << current
    current_related_array = get_transverse_verices(current)
    
    current_related_array.each do |vertex|
      next if every_traverse_array.include?(vertex) || stack.include?(vertex)
      stack.push(vertex)
    end
  end
  return every_traverse_array
end
# 删除重复的边
def remove_duplicate_edges(entities)
  edge_set = {} # 使用哈希表来存储唯一的边信息

  entities.grep(Sketchup::Edge).each do |edge|
    # 获取边的两个顶点位置，并转换为数组形式，以便排序
    vertices = edge.vertices
    key = [vertices[0].position.to_a, vertices[1].position.to_a].sort

    if edge_set[key]
      # 如果该边已存在于哈希表中，删除当前边
      entities.erase_entities(edge)
      puts "Duplicate edge deleted: #{edge}"
    else
      # 否则将边加入哈希表中
      edge_set[key] = true
    end
  end
end
def remove_duplicate_faces(entities)
  face_set = {} # 使用哈希表来存储唯一的面信息

  entities.grep(Sketchup::Face).each do |face|
    # 获取面的顶点位置，并将它们转换为数组形式进行排序，以确保唯一性
    vertices_positions = face.vertices.map { |v| v.position.to_a }.sort

    if face_set[vertices_positions]
      # 如果该面已存在于哈希表中，删除当前面
      entities.erase_entities(face)
      puts "Duplicate face deleted: #{face}"
    else
      # 否则将面加入哈希表中
      face_set[vertices_positions] = true
    end
  end
end
#创建插件，实现命令
toolbar_transform = UI::Toolbar.new 'Decode'
#创建命令（主函数）并在其中调用各函数
plugin = UI::Command.new('Topo_transform'){
  # Default code, use or delete...
  mod = Sketchup.active_model # Open model
  ent = mod.entities # All entities in model
  sel = mod.selection # Current selection
  
  all_vertices_array=Array.new()
  
  excel = WIN32OLE::new('excel.Application')
  excel_file_path = UI.openpanel("选择 Excel 文件","","Excel Files|*.xlsx||")
  if excel_file_path
    puts "成功打开文件"
  else
    UI.messagebox("未选择excel文件")
  end
  workbook = excel.Workbooks.Open(excel_file_path)
  worksheet = workbook.Worksheets(1)
  line1 = 2
  while worksheet.Range("a#{line1}").value
    line1=line1+1
  end
    
  for i in (0..line1-3)
    all_vertices_array[i]=[worksheet.Range("b#{i+2}").value.m,worksheet.Range("c#{i+2}").value.m,worksheet.Range("d#{i+2}").value.m]#所有的顶点
  end
  num = 0 #已经遍历的顶点数目
  vertical_num = 1
  plane_array=Array.new()#生成的非竖直面的顶点
  face_num_array=Array.new()#存储生成的非竖直面
  
  puts '模型绘制中...'
  current_face_array = Array.new()
  current_on_line_vertices = Array.new()
  for i in(0..all_vertices_array.length-1)
    if current_on_line_vertices.length < 3
      current_face_array << all_vertices_array[i]
      current_on_line_vertices << all_vertices_array[i]
      next if current_on_line_vertices.length < 3
      if collinear?(current_on_line_vertices[0],current_on_line_vertices[1],current_on_line_vertices[2])
        current_on_line_vertices.pop
        next
      end
    else
      plane = [current_on_line_vertices[0],current_on_line_vertices[1],current_on_line_vertices[2]]
      if all_vertices_array[i].on_plane?(plane)
        current_face_array << all_vertices_array[i]
      else
        if current_face_array.length >= 3
          face_num_array << ent.add_face(current_face_array)
          plane_array << current_face_array
        end
      current_face_array = [all_vertices_array[i]]
      current_on_line_vertices = [all_vertices_array[i]]
      end
    end
  end
  if current_face_array.length >=3
    face_num_array << ent.add_face(current_face_array)
    plane_array << current_face_array
  end
  
  puts '绘制竖直面...'

  # 还原全部竖直面
  all_lines_array = []

  # 构建顶点映射，将具有相同 x, y 值的顶点分组
  all_vertices_map = Hash.new { |hash, key| hash[key] = [] }

  # 将所有顶点根据其 x 和 y 值存入映射中
  all_vertices_array.each do |vertex|
    key = [vertex[0].round(3), vertex[1].round(3)] # 使用 x 和 y 坐标作为键（并四舍五入确保精度一致）
    all_vertices_map[key] << vertex
  end

    # 添加竖直面线条
    TOLERANCE_Z = 0.001 # 设置 Z 轴距离容差

    all_vertices_map.each_value do |vertices|
      # 如果具有相同 x, y 值的顶点数量小于 2，说明无法生成竖直面，跳过
      next if vertices.length < 2

      # 对每组具有相同 x, y 值的顶点，按 z 值排序
      sorted_vertices = vertices.sort_by { |v| v[2] }

      # 依次将相邻顶点连接，确保每组点仅绘制必要的竖直线段
      (0...sorted_vertices.length - 1).each do |i|
        v1 = sorted_vertices[i]
        v2 = sorted_vertices[i + 1]

        # 检查 z 值的差异是否大于容差，以避免绘制过于接近的竖直线段
        if (v2[2] - v1[2]).abs > TOLERANCE_Z
          line = ent.add_line(v1, v2)
          all_lines_array << line if line
        end
      end
    end

    # 去重
    all_lines_array.uniq!

    # 查找面
    all_lines_array.each do |line|
      line.find_faces if line.valid?
    end
    faces_array = ent.grep(Sketchup::Face)

    # 用于收集需要删除的面
    faces_to_erase = []

    # 遍历面并检查包含关系
    faces_array.combination(2).each do |face1, face2|
      # 检查面是否已被删除
      next if !face1.valid? || !face2.valid?

      # 判断两个面之间的包含关系
      if face1.bounds.contains?(face2.bounds) && face2.area < face1.area
        # 如果 face2 完全在 face1 内部并且面积较小，标记 face2 以删除
        faces_to_erase << face2 unless faces_to_erase.include?(face2)
        puts "Face #{face2} marked for deletion as it was inside Face #{face1}"
      elsif face2.bounds.contains?(face1.bounds) && face1.area < face2.area
        # 如果 face1 完全在 face2 内部并且面积较小，标记 face1 以删除
        faces_to_erase << face1 unless faces_to_erase.include?(face1)
        puts "Face #{face1} marked for deletion as it was inside Face #{face2}"
      end
    end

    # 删除所有标记的面
    ent.erase_entities(faces_to_erase) unless faces_to_erase.empty?
    remove_duplicate_edges(ent)
    remove_duplicate_faces(ent)
    UI.messagebox '模型还原完成！'
    puts '模型还原完成！' 
  }

  plugin.large_icon = "large.png"
  plugin.small_icon = "small.png"
  plugin.tooltip = "topology and position!"
  plugin.status_bar_text = "get topology and position of vertex"
  plugin.menu_text = "Transform"

  toolbar_transform = toolbar_transform.add_item plugin
  toolbar_transform.show


  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
