#操作excel
require 'win32ole'
# Default code, use or delete...
mod = Sketchup.active_model # Open model
ent = mod.entities # All entities in model
sel = mod.selection # Current selection

#获取顶点的拓扑关系（点与点的关系）
def get_related_vertices(vex1)
  related_vertices_array=Array.new()
  edges_array=vex1.edges
  edges_array.each do |one_edge|
    edge_vertices_array=one_edge.vertices
    edge_vertices_array.each do |one_vertex|
      if(vex1 == one_vertex)
        next
      else
        related_vertices_array << one_vertex
      end
    end
  end
  related_vertices_array=related_vertices_array.uniq
  return related_vertices_array
end

#获取一条边在当前面内的邻接边
def get_related_edge(edge1, face1)
  all_edges_array = Array.new()
  all_edges_array = face1.edges
  
  all_edges_array.delete(edge1)
  
  edge1_vex_arr = Array.new()
  edge1_vex_arr = edge1.vertices
  
  for i in(0..all_edges_array.length-1)
    noedge_vex_arr = Array.new()
    noedge_vex_arr = all_edges_array[i].vertices
    
    for j in(0..edge1_vex_arr.length-1)
      for k in(0..noedge_vex_arr.length-1)
        if(edge1_vex_arr[j] == noedge_vex_arr[k])
          return edge1_vex_arr[j], all_edges_array[i]
        end
      end
    end
  end
end

#对俩条边进行逆时针排序 返回逆时针顺序的俩条边与顶点
def get_order_edges(vex0, edge1, edge2, face1)
  vex1 = edge1.other_vertex(vex0)
  vex2 = edge2.other_vertex(vex0)
  
  point0 = vex0.position
  point1 = vex1.position
  point2 = vex2.position
  
  normal1 = face1.normal
  
  vec1 = Geom::Vector3d.new(point1, point0)
  vec2 = Geom::Vector3d.new(point0, point2)
  
  vec = vec1 * vec2
  
  angle1 = vec.angle_between normal1
  
  if(angle1 >= 0 && angle1 <= 1)
    #逆时针
    return vex1, vex2, edge1, edge2
  else
    #顺时针
    return vex2, vex1, edge2, edge1
  end
end

#获取顶点vex2在面内的邻接点(vex1为已知邻接点)
def get_face_vex(vex1, vex2, face1)
  face1_vex_arr = Array.new()
  face1_vex_arr = face1.vertices
  
  face1_vex_arr.delete(vex1)
  
  related_vex_arr = Array.new()
  related_vex_arr = get_related_vertices(vex2)
  
  related_vex_arr.delete(vex1)
  
  for i in(0..face1_vex_arr.length-1)
    for j in(0..related_vex_arr.length-1)
      if(face1_vex_arr[i] == related_vex_arr[j])
        return face1_vex_arr[i]
      end
    end   
  end
end

#获取边的右邻接面
def get_right_face(vex1, vex0, edge1)
  edge1_faces_array = Array.new()
  edge1_faces_array = edge1.faces

  point0 = vex0.position
  point1 = vex1.position
  vec1 = Geom::Vector3d.new(point1, point0)
  
  for i in(0..edge1_faces_array.length-1)
    
    normal1 = edge1_faces_array[i].normal
    
    vex2 = get_face_vex(vex1, vex0, edge1_faces_array[i])
    point2 = vex2.position

    vec2 = Geom::Vector3d.new(point0, point2)
    
    vec = vec1 * vec2
    
    angle1 = vec.angle_between normal1
    
    if(angle1 > 3 && angle1 < 4)
      return vex2, edge1_faces_array[i]
    end   
  end
end

#创建插件，实现命令
toolbar_transform = UI::Toolbar.new 'triangle'
#创建命令（主函数）调用各函数
plugin = UI::Command.new('print_triangle'){
  # Default code, use or delete...
  mod = Sketchup.active_model # Open model
  ent = mod.entities # All entities in model
  sel = mod.selection # Current selection

  #遍历所有的组，判断组里的所有面  
  group_array=ent.grep(Sketchup::Group)
  face_array=ent.grep(Sketchup::Face)
  all_face_array=Array.new()
  model_vertices_array=Array.new()
  
  #遍历组中的所有面
  if group_array.length>0
    UI.messagebox "the number of group is:"+group_array.length.to_s
    group_array.each do |one_group|      
      one_group_entities=one_group.entities
      one_group_face=one_group_entities.grep(Sketchup::Face)
      one_group_face.each do |one_face|
        all_face_array << one_face
        vt=one_face.vertices
        for i in (0..vt.length-1)
          group_vertices_array << vt[i]
        end
      end
      group_vertices_array=group_vertices_array.uniq
      model_vertices_array << group_vertices_array
    end       
  else
    UI.messagebox "the number of group is 0"
  end
  
  #遍历非组面
  face_vertices_array=Array.new()
  if face_array.length>0
    face_array.each do |one_face|
      all_face_array << one_face
      vtarr=one_face.vertices
      for i in (0..vtarr.length-1)
        face_vertices_array << vtarr[i]
      end
    end 
    face_vertices_array=face_vertices_array.uniq
    
    for i in (0..face_vertices_array.length-1)
      model_vertices_array << face_vertices_array[i]
    end 
  else
    UI.messagebox "no independent faces or edges"
  end
  
  #模型中的所有面
  model_faces_array = all_face_array.uniq

  #模型中的全部顶点
  model_vertices_array = model_vertices_array.uniq
  
  #已遍历的顶点
  traversed_vertices_array = Array.new()

  #一、先获取起始的俩条边  生成初始三角形
  
  #1、先获取第一条边
  start_face = model_faces_array[0]
  
  start_edges_array = Array.new()
  start_edges_array = start_face.edges
  
  start_edge1 = start_edges_array[0]
  
  #2、获取第二条边
  comvex, start_edge2 = get_related_edge(start_edge1, start_face)
  
  #3、逆时针排序俩条边
  vex1, vex2, edge1, edge2 = get_order_edges(comvex, start_edge1, start_edge2, start_face)
  
  edge3 = ent.add_line(vex1, vex2)
  #face11 = ent.add_face(vex1, vex2, comvex)
  
  #4、存储已遍历的顶点
  traversed_vertices_array << comvex
  traversed_vertices_array << vex2
  traversed_vertices_array << vex1
  
  #二、循环遍历：选取起始边 获取起始边的右邻接面 寻找右邻接面中未遍历的顶点构成三角面
  
  #1、获取起始边
  start_edge = edge1
  vex0 = comvex
  
  #2、循环遍历
  while(traversed_vertices_array.length < model_vertices_array.length)
    bool = 0 
    while(bool == 0)
      # 获取边的右邻接面与面内邻接点
      vex3, right_face = get_right_face(vex1, vex0, start_edge)
      
      point0 = vex0.position
      point1 = vex1.position
      point3 = vex3.position

      # 连接vex1、vex3
      nedge = ent.add_line(point1, point3)

      tbool = 0
      #判断vex3是否已经存储到traversed（即是否已经存储遍历）
      for i in(0..traversed_vertices_array.length-1)
        if(vex3 == traversed_vertices_array[i])
          tbool = 1
          break
        end
      end
      
      if(tbool == 0) #未遍历
        traversed_vertices_array << vex3
        start_edge = vex0.common_edge vex3
        vex1 = vex3
        bool = 1
      else #已遍历
        start_edge = nedge
        vex0 = vex3
      end
    end

    if(traversed_vertices_array.length == model_vertices_array.length)
      #puts '最后一次遍历'
      
      #最后一次遍历
      bool = 1
        
      stavex = vex1
      endvex = vex0 
        
      endegde = ent.add_line(stavex, endvex)
        
      end_bool = 0
      while(end_bool == 0) 
        #获取右邻接面
        facvex, endface = get_right_face(stavex, endvex, endegde)
        
        next_edge = ent.add_line(stavex, facvex)
        
        endvex = facvex
        endegde = next_edge
        
        if(facvex == vex0)
          end_bool = 1
        end
      end  
    end   
  end
  
  traversed_point_array = Array.new()
  for i in(0..traversed_vertices_array.length-1)
    traversed_point_array << traversed_vertices_array[i].position
  end
  
  #将顶点信息存储为一维点串
  save_path = UI.savepanel("选择保存位置", "C:\\Users\\SZU\\Desktop", "output.xlsx")
  if save_path.nil?
    UI.messagebox "未选择保存路径，导出已取消。"
    return
  end
  myexcel1 = WIN32OLE.new("excel.application")
  myexcel1.visible = false
  mywbk1 = myexcel1.Workbooks.Add()
  mywst1 = mywbk1.Worksheets(1)
  arr=Array.new()
  arr=['No.','X','Y','Z']
  mywst1.Range('A1:D1').value = arr  
  
  for num in (0..traversed_vertices_array.length-1)
    mywst1.Range("A#{num+2}").value = num+1
    mywst1.Range("B#{num+2}").value = traversed_point_array[num].x.to_m
    mywst1.Range("C#{num+2}").value = traversed_point_array[num].y.to_m
    mywst1.Range("D#{num+2}").value = traversed_point_array[num].z.to_m
  end

  mywbk1.SaveAs save_path
  mywbk1.Close
  UI.messagebox "遍历完成! 文件已保存到: #{save_path}"
  
  #UI.messagebox "vertices_array had finished!"
  puts '遍历完成！'
  
}

plugin.large_icon = "large.png"
plugin.small_icon = "small.png"
plugin.tooltip = "vertices and faces!"
plugin.status_bar_text = "print triangle mesh information!"
plugin.menu_text = "Triangle"

toolbar_transform = toolbar_transform.add_item plugin
toolbar_transform.show






