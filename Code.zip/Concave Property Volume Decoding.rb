require 'win32ole'
# Default code, use or delete...
mod = Sketchup.active_model # Open model
ent = mod.entities # All entities in model
sel = mod.selection # Current selection

#创建插件，实现命令
toolbar_transform = UI::Toolbar.new 'Transform'

#创建命令（主函数）调用各函数
plugin = UI::Command.new('topo_transform'){ 
  # Default code, use or delete...
  mod = Sketchup.active_model # Open model
  ent = mod.entities # All entities in model
  sel = mod.selection # Current selection
  
  
  ########## 一、模型初步还原（生成初始边线） ##########
  
  
  #存储读取的所有顶点信息
  all_vertices_array = Array.new()
  all_mark_array = Array.new()
  
  #打开excel文件
  #创建数组，存储顶点坐标信息
  #vex_array[i].x=worksheet.Range('a#{i+1}')['Value']
  excel = WIN32OLE::new('excel.Application')
  excel_file_path = UI.openpanel("选择 Excel 文件","","Excel Files|*.xlsx||")
  if excel_file_path
    puts "成功打开文件"
  else
    UI.messagebox("未选择excel文件")
  end
  workbook = excel.Workbooks.Open(excel_file_path)
  worksheet = workbook.Worksheets(1)
  #确定顶点数量
  line1 = 2
  while worksheet.Range("a#{line1}").value
    line1=line1+1
  end
  
  #读取点串信息
  for i in (0..line1-3)
    #读取坐标信息
    all_vertices_array[i]=[worksheet.Range("c#{i+2}").value.m,worksheet.Range("d#{i+2}").value.m,worksheet.Range("e#{i+2}").value.m]#所有的顶点
    #读取mark信息
    all_mark_array[i] = worksheet.Range("f#{i+2}").value
  end
  
  #标识数组中的值转为整数
  all_mark_array = all_mark_array.map(&:to_i)
  
  #先取前三个顶点 构成初始三角面
  face1 = ent.add_face(all_vertices_array[0], all_vertices_array[1], all_vertices_array[2])
  
  face1.material = Sketchup::Color.new(255, 0, 0)
  
  #按照顶点顺序进行连接 获取初始的所有边线
  traversed_edges_array = Array.new()
  for i in(0..all_vertices_array.length-2)
    start_edge = ent.add_line(all_vertices_array[i],all_vertices_array[i+1])
    traversed_edges_array << start_edge
  end
  
  puts '初始边线还原完成！'
  
  
  ########## 二、模型初步还原（三角面初步还原） ##########
  
  
  #已经遍历的顶点数（前三个点）
  tranum = 3
  traversed_vertices_array = Array.new()
  traversed_vertices_array << all_vertices_array[0]
  traversed_vertices_array << all_vertices_array[1]
  traversed_vertices_array << all_vertices_array[2]
  
  #每个顶点当前已经遍历的顶点数  除了第三个顶点其余全部为2（首尾连接）
  related_number_array = Array.new()
  for i in(0..all_vertices_array.length-1)
    related_number_array[i] = 2
  end
  #初始三角面连接的顶点 多一个邻接点
  related_number_array[2] = 3
  
  #开始遍历
  for i in(0..all_vertices_array.length-1) 
    if(tranum == all_vertices_array.length)
      last_num = i
      break
    end
    
    #先获取当前顶点的邻接点数
    sum = all_mark_array[i]
    #当前顶点已遍历邻接点数
    num = related_number_array[i]
    #当前顶点未遍历邻接点数
    no_num = sum - num
    
    if(i < all_vertices_array.length-1)
      #先获取下一个顶点的邻接点数
      sum1 = all_mark_array[i+1]
      #下一个顶点已遍历邻接点数
      num1 = related_number_array[i+1]
      #下一个顶点未遍历邻接点数
      no_num1 = sum1 - num1
    else
      no_num1 = 1
    end

    ##当前顶点邻接点存在未遍历邻接点，下一个顶点邻接点也存在未遍历邻接点
    if(no_num > 0 && no_num1 != 0)
      if(i == 0)
        #连接当前遍历顶点与上一个顶点构成的三角面
        face2 = ent.add_face(all_vertices_array[0], all_vertices_array[2], all_vertices_array[tranum])
        #face2.material = Sketchup::Color.new(37, 175, 240)
        #相应顶点的邻接点数加1
        related_number_array[i] = related_number_array[i] + 1
        related_number_array[tranum] = related_number_array[tranum] + 1
        
        tranum = tranum + 1
        no_num = no_num - 1
        
        while(no_num > 0)
          #生成三角面
          face2 = ent.add_face(all_vertices_array[i], all_vertices_array[tranum-1], all_vertices_array[tranum])
          #face2.material = Sketchup::Color.new(37, 175, 240)
          #相应顶点的邻接点数加1
          related_number_array[i] = related_number_array[i] + 1
          related_number_array[tranum] = related_number_array[tranum] + 1
          no_num = no_num - 1
          tranum = tranum + 1
        end
      else
        #连接当前遍历顶点与上一个顶点构成的三角面
        face2 = ent.add_face(all_vertices_array[i], all_vertices_array[i-1], all_vertices_array[tranum-1])
        #face2.material = Sketchup::Color.new(37, 175, 240)
        #相应顶点的邻接点数加1
        related_number_array[i] = related_number_array[i] + 1
        related_number_array[tranum-1] = related_number_array[tranum-1] + 1
          
        no_num = no_num - 1
        while(no_num > 0)
          #生成三角面
          face2 = ent.add_face(all_vertices_array[i], all_vertices_array[tranum-1], all_vertices_array[tranum])
          #face2.material = Sketchup::Color.new(37, 175, 240)
          #相应顶点的邻接点数加1
          related_number_array[i] = related_number_array[i] + 1
          related_number_array[tranum] = related_number_array[tranum] + 1
          no_num = no_num - 1
          tranum = tranum + 1
        end
      end
    #当前顶点邻接点存在未遍历邻接点，下一个顶点邻接点均已遍历
    elsif(no_num > 0 && no_num1 == 0)
      face2 = ent.add_face(all_vertices_array[i], all_vertices_array[i+2], all_vertices_array[i+1])
      #face2.material = Sketchup::Color.new(37, 175, 240)
      
      related_number_array[i] = related_number_array[i] + 1
      related_number_array[i+2] = related_number_array[i+2] + 1
      no_num = no_num - 1
      
      if(no_num > 0)
        #连接当前遍历顶点与上一个顶点构成的三角面
        face2 = ent.add_face(all_vertices_array[i], all_vertices_array[i-1], all_vertices_array[tranum-1])
        #face2.material = Sketchup::Color.new(37, 175, 240)
        #相应顶点的邻接点数加1
        related_number_array[i] = related_number_array[i] + 1
        related_number_array[tranum-1] = related_number_array[tranum-1] + 1
        no_num = no_num - 1

        while(no_num > 0)
          #生成三角面
          face2 = ent.add_face(all_vertices_array[i], all_vertices_array[tranum-1], all_vertices_array[tranum])
          #face2.material = Sketchup::Color.new(37, 175, 240)
          #相应顶点的邻接点数加1
          related_number_array[i] = related_number_array[i] + 1
          related_number_array[tranum] = related_number_array[tranum] + 1
          no_num = no_num - 1
          tranum = tranum + 1
        end  
      end
      all_vertices_array[i+1] = all_vertices_array[i]
    else
      next
    end  
  end
  #最后一个顶点会多加一次邻接点数 减掉1
  related_number_array[tranum-1] = related_number_array[tranum-1] - 1
  
  puts '初始模型还原完成！'
  
  
  ########### 三、网格修复（针对孔洞进行修复） ##########
  
  
  #获取剩余的所有未遍历完全的边线
  remain_edges_array = Array.new()
  for i in(last_num..all_vertices_array.length-2)
    edge1 = ent.add_line(all_vertices_array[i], all_vertices_array[i+1])
    remain_edges_array << edge1
  end
  edge2 = ent.add_line(all_vertices_array[last_num-1], all_vertices_array[all_vertices_array.length-1])
  remain_edges_array << edge2
  
  #剩余未完全遍历的顶点
  remain_num = all_vertices_array.length - last_num + 1
  remain_vertices_array = Array.new()
  for i in(last_num-1..all_vertices_array.length-1)
    remain_vertices_array << all_vertices_array[i]
  end
  
  #剩余顶点对应的所有邻接点数、已遍历邻接点数
  remain_mark_array = Array.new()
  traversed_mark_array = Array.new()
  for i in(last_num-1..all_vertices_array.length-1)
    remain_mark_array << all_mark_array[i]
    traversed_mark_array << related_number_array[i]
  end
  
  #存储当前次遍历之前的顶点已遍历邻接点数
  clone_mark_array = Array.new()
  clone_mark_array = traversed_mark_array.dup
  
  #循环遍历剩余顶点
  while(remain_num > 0)  
    #更新当前次遍历的顶点的已遍历邻接点数
    traversed_mark_array = clone_mark_array.dup

    #存储每次循环后完成遍历的顶点信息
    delete_index_array = Array.new()

    #遍历当前次的顶点数组
    for i in(0..remain_vertices_array.length-1)
      #先获取当前顶点的邻接点数
      sum2 = remain_mark_array[i]
      #当前顶点已遍历邻接点数
      num2 = traversed_mark_array[i]
      #当前顶点未遍历邻接点数
      no_num2 = sum2 - num2
      
      #已遍历完成
      if(no_num2 == 0)  
        #遍历完全的顶点
        delete_index_array << i
        
        #处理不同类型的顶点
        if(i == 0)
          #生成三角面
          face3 = ent.add_face(remain_vertices_array[i],remain_vertices_array[remain_vertices_array.length-1],remain_vertices_array[i+1])
          face3.material = Sketchup::Color.new(207, 153, 251)
          
          #更新邻接点数
          clone_mark_array[i+1] = clone_mark_array[i+1] + 1
          clone_mark_array[remain_vertices_array.length-1] = clone_mark_array[remain_vertices_array.length-1] + 1
        elsif(i == remain_vertices_array.length-1)
          #生成三角面
          face3 = ent.add_face(remain_vertices_array[i],remain_vertices_array[i-1],remain_vertices_array[0])
          face3.material = Sketchup::Color.new(207, 153, 251)
          
          #更新邻接点数
          clone_mark_array[i-1] = clone_mark_array[i-1] + 1
          clone_mark_array[0] = clone_mark_array[0] + 1
        else
          #生成三角面
          face3 = ent.add_face(remain_vertices_array[i],remain_vertices_array[i-1],remain_vertices_array[i+1])
          face3.material = Sketchup::Color.new(207, 153, 251)
          
          #更新邻接点数
          clone_mark_array[i-1] = clone_mark_array[i-1] + 1
          clone_mark_array[i+1] = clone_mark_array[i+1] + 1        
        end
        #遍历完全的顶点加1
        remain_num = remain_num - 1
      else
        next
      end
    end  
    
    #删除数组对应位置的元素
    delete_index_array.sort.reverse_each do |index|
      remain_vertices_array.delete_at(index)
    end
    
    delete_index_array.sort.reverse_each do |index|
      remain_mark_array.delete_at(index)
    end    

    delete_index_array.sort.reverse_each do |index|
      clone_mark_array.delete_at(index)
    end
    break if delete_index_array.empty?
  end  
  
  puts '网格修复完成！'
  
  ########## 四、多边形还原 ##########
  

  #遍历俩次 确保每个面都还原
  number = 2
while(number > 0)
  number -= 1
  # 三角面还原为多边形面
  # 1、先获取所有的三角面
  all_faces_array = Array.new()
  all_faces_array = ent.grep(Sketchup::Face)

  # 2、判断当前三角面的邻接面是否平行于当前面
  i = 0
  while i < all_faces_array.length
    face11 = all_faces_array[i]
    if face11.nil?
      i += 1
      next
    end

    # 获取邻接面
    face_edges_array = face11.edges

    j = 0
    while j < face_edges_array.length
      face_edge = face_edges_array[j]
      related_faces_array = face_edge.faces
      related_faces_array.delete(face11)

      if related_faces_array.empty?
        j += 1
        next
      end

      face22 = related_faces_array[0]
      if face22.nil?
        j += 1
        next
      end

      normal11 = face11.normal
      normal22 = face22.normal

      angle11 = normal11.angle_between(normal22)

      # 3、平行：删去共边
      if angle11 >= 0 && angle11 <= 0.000001
        face_edge.erase!
        all_faces_array.delete(face22)
        break
      else
        j += 1
      end
    end
    i += 1
  end
end
}

plugin.large_icon = "large.png"
plugin.small_icon = "small.png"
plugin.tooltip = "topology and position!"
plugin.status_bar_text = "get topology and position of vertex"
plugin.menu_text = "Transform"

toolbar_transform = toolbar_transform.add_item plugin
toolbar_transform.show

