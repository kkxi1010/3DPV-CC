#将2.5维模型按照规则转换为一维点串
#实现模型的降维表达
require 'win32ole'

# Default code, use or delete...
mod = Sketchup.active_model # Open model
ent = mod.entities # All entities in model
sel = mod.selection # Current selection

#获取顶点的拓扑关系（点与点的关系）
def get_related_vertices(vex1)
  related_vertices_array = Array.new()
  edges_array = vex1.edges
  edges_array.each do |one_edge|
    other_vertex = one_edge.other_vertex(vex1)
    related_vertices_array << other_vertex
  end
  related_vertices_array.uniq
  return related_vertices_array
end

#获取顶点的非竖直邻接点
def get_transverse_vertices(vex1)
  vex1_array = get_related_vertices(vex1)
  vex1_new_array = Array.new()
  vex1_array.each do |vertex|
    point1 = vex1.position
    point2 = vertex.position
    next if point1.x == point2.x && point1.y == point2.y
    vex1_new_array << vertex
  end
  return vex1_new_array
end

#获取顶点的竖直邻接点
def get_vertical_vertices(vex1,no_traverse_array)
  tr=0
  num=0
  point1=vex1.position
  for i in(0..no_traverse_array.length-1)
    point2=no_traverse_array[i].position
    if(point1.x==point2.x && point1.y==point2.y && point1!=point2)
      tr=1
      num=i
      break
    end
  end
  return tr,no_traverse_array[num]
end

#获取模型的非竖直面
def get_transverse_face(vex1_first,vex1,vex2,vex3,every_traverse_array)  
  vex3_transverse_array=Array.new()
  vex3_transverse_array=get_transverse_vertices(vex3) #C的非竖直邻接点
  
  for i in (0..vex3_transverse_array.length-1) 
    if(vex3_transverse_array[i]==vex1_first)
      return every_traverse_array
    elsif(vex3_transverse_array[i]==vex2)
      next
    else
      vex4=vex3_transverse_array[i]
      every_traverse_array << vex4
      get_transverse_face(vex1_first,vex2,vex3,vex4,every_traverse_array)
    end
  end
  return every_traverse_array
end

#创建插件，实现命令
toolbar_transform = UI::Toolbar.new 'Transform'

#创建命令（主函数）调用各函数
plugin = UI::Command.new('topo_transform'){ 
  # Default code, use or delete...
  mod = Sketchup.active_model # Open model
  ent = mod.entities # All entities in model
  sel = mod.selection # Current selection
  
  #遍历所有的组，判断组里的所有面  
  group_array=ent.grep(Sketchup::Group)
  group_vertices_array=Array.new()
  face_array=ent.grep(Sketchup::Face)
  face_vertices_array=Array.new()
  
  #遍历模型中的所有点
  model_vertices_array=Array.new()
  
  #遍历组中的所有顶点
  if group_array.length>0
    UI.messagebox "the number of group is:"+group_array.length.to_s
    group_array.each do |one_group|      
      one_group_entities=one_group.entities
      one_group_face=one_group_entities.grep(Sketchup::Face)
      one_group_face.each do |one_face|
        vt=one_face.vertices
        for i in (0..vt.length-1)
          group_vertices_array << vt[i]
        end
      end
      group_vertices_array=group_vertices_array.uniq
      model_vertices_array << group_vertices_array
    end       
  else
    UI.messagebox "the number of group is 0"
  end
  
  #遍历非组面中的所有顶点
  if face_array.length>0
    face_array.each do |one_face|
      vtarr=one_face.vertices
      for i in (0..vtarr.length-1)
        face_vertices_array << vtarr[i]
      end
    end
    
    face_vertices_array=face_vertices_array.uniq
    
    for i in (0..face_vertices_array.length-1)
      model_vertices_array << face_vertices_array[i]
    end
  
  else
    UI.messagebox "no independent faces or edges"
  end

  #存储拓扑信息和位置节点信息
  model_vertices_array=model_vertices_array.uniq #模型中的所有顶点

  #遍历顶点，生成一维点串
  #先获取顶点的非竖直邻接点

  all_traverse_array=Array.new()#所有已遍历非竖直面的顶点
  no_traverse_array=Array.new()#未遍历的顶点

  no_traverse_array = model_vertices_array
  last_face_array=Array.new()#存储上一个已经遍历的面的所有顶点

  while(no_traverse_array.length > 0)
    every_traverse_array1=Array.new()#每一次遍历面的所有顶点

    #先判断是否已经开始遍历
    if(last_face_array.length == 0)   
      vex1=no_traverse_array[0] #起始遍历顶点
      every_traverse_array1 << vex1
      vex1_first = vex1
      
      vex1_transverse_array=Array.new()
      vex1_transverse_array=get_transverse_vertices(vex1)#A的非竖直邻接点数组  
    
      #UI.messagebox '111'
      vex2=vex1_transverse_array[0]#B
      every_traverse_array1 << vex2 #第二个顶点存入数组

      vex2_transverse_array=Array.new()
      vex2_transverse_array=get_transverse_vertices(vex2)#B的非竖直邻接点数组A、C

      for i in (0..vex2_transverse_array.length-1)#寻找vex2未遍历的邻接点
        if(vex2_transverse_array[i]==vex1)
          next
        else
          vex3=vex2_transverse_array[i]#C
          every_traverse_array1 << vex3
          break
        end
      end       
    else
      for i in(0..no_traverse_array.length-1)
        #判断遍历起始顶点是否与上一个面共面
        #共面：next  不共面：作为遍历面起始点
        last_point0=last_face_array[0].position
        last_point1=last_face_array[1].position
        last_point2=last_face_array[2].position
        
        no_point=no_traverse_array[i].position
        
        plane = [last_point0,last_point1,last_point2]
        status = no_point.on_plane?(plane)

        if(status)
          #共面
          #puts '共面！'
          next
        else
          #不共面
          vex1=no_traverse_array[i]
          every_traverse_array1 << vex1
          vex1_first = vex1  

          vex1_transverse_array=Array.new()
          vex1_transverse_array=get_transverse_vertices(vex1)#A的非竖直邻接点数组  

          #UI.messagebox '111'
          vex2=vex1_transverse_array[0]#B
          every_traverse_array1 << vex2 #第二个顶点存入数组

          vex2_transverse_array=Array.new()
          vex2_transverse_array=get_transverse_vertices(vex2)#B的非竖直邻接点数组A、C

          for j in (0..vex2_transverse_array.length-1)#寻找vex2未遍历的邻接点
            if(vex2_transverse_array[j]==vex1)
              next
            else
              vex3=vex2_transverse_array[j]#C
              every_traverse_array1 << vex3
              break
            end
          end 
          break
        end               
      end     
    end
    
    #循环遍历，找到一个面中的所有顶点
    every_traverse_array1=get_transverse_face(vex1_first,vex1,vex2,vex3,every_traverse_array1)

    #依次将每个面中的顶点存入一维点串中
    for i in (0..every_traverse_array1.length-1)
      all_traverse_array << every_traverse_array1[i]
    end   
    
    #筛选未遍历的顶点    
    for i in(0..every_traverse_array1.length-1)
      for j in(0..no_traverse_array.length-1)
        if(every_traverse_array1[i]==no_traverse_array[j])
          no_traverse_array.delete_at(j)
          #no_traverse_array.delete(no_traverse_array[no_traverse_array.length-1])#每次删去最后一个顶点
        end
      end
    end
    
    tr=0
    #获取顶点竖直邻接点进行遍历
    for i in(0..every_traverse_array1.length-1)
      every_traverse_array2=Array.new()
      tr,vertical_vex = get_vertical_vertices(every_traverse_array1[i],no_traverse_array)
      if(tr > 0)
        vex1=vertical_vex
        every_traverse_array2 << vex1
        vex1_first = vex1  
        
        vex1_transverse_array=Array.new()
        vex1_transverse_array=get_transverse_vertices(vex1)#A的非竖直邻接点数组
        
        vex2=vex1_transverse_array[0]#B
        every_traverse_array2 << vex2 #第二个顶点存入数组

        vex2_transverse_array=Array.new()
        vex2_transverse_array=get_transverse_vertices(vex2)#B的非竖直邻接点数组A、C

        for i in (0..vex2_transverse_array.length-1)#寻找vex2未遍历的邻接点
          if(vex2_transverse_array[i]==vex1)
            next
          else
            vex3=vex2_transverse_array[i]#C
            every_traverse_array2 << vex3
            break
          end
        end               
        every_traverse_array2=get_transverse_face(vex1_first,vex1,vex2,vex3,every_traverse_array2)
        #puts every_traverse_array2.length #每个面中顶点的个数
        break
      else
        next
      end   
    end
    
    last_face_array=every_traverse_array2  

    #依次将每个面中的顶点存入一维点串中
    for i in (0..every_traverse_array2.length-1)
      all_traverse_array << every_traverse_array2[i]
    end  
    
    #筛选未遍历的顶点    
    for i in(0..every_traverse_array2.length-1)
      for j in(0..no_traverse_array.length-1)
        if(every_traverse_array2[i]==no_traverse_array[j])
          no_traverse_array.delete_at(j)
          #no_traverse_array.delete(no_traverse_array[no_traverse_array.length-1])#每次删去最后一个顶点
        end
      end
    end  
  end
  point_array=Array.new()
  for l in (0..all_traverse_array.length-1)
    point_array[l]=all_traverse_array[l].position
  end
  save_path = UI.savepanel("选择保存位置", "C:\\Users\\SZU\\Desktop", "output.xlsx")
  if save_path.nil?
    UI.messagebox "未选择保存路径，导出已取消。"
    return
  end
  myexcel1 = WIN32OLE.new("excel.application")
  myexcel1.visible = false
  mywbk1 = myexcel1.Workbooks.Add()
  mywst1 = mywbk1.Worksheets(1)
  arr=Array.new()
  arr=['No.','Lontitude','Latitude','Height']
  mywst1.Range('A1:D1').value = arr

  for num in (0..all_traverse_array.length-1)
    mywst1.Range("A#{num+2}").value = num+1
    mywst1.Range("B#{num+2}").value = point_array[num].x.to_m
    mywst1.Range("C#{num+2}").value = point_array[num].y.to_m
    mywst1.Range("D#{num+2}").value = point_array[num].z.to_m
  end

  mywbk1.SaveAs save_path
  mywbk1.Close
  UI.messagebox "excel Had Finished!"    
}

plugin.large_icon = "large.png"
plugin.small_icon = "small.png"
plugin.tooltip = "topology and position!"
plugin.status_bar_text = "get topology and position of vertex"
plugin.menu_text = "Transform"

toolbar_transform = toolbar_transform.add_item plugin
toolbar_transform.show







