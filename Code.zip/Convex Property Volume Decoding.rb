require 'win32ole'
# Default code, use or delete...
mod = Sketchup.active_model # Open model
ent = mod.entities # All entities in model
sel = mod.selection # Current selection

#获取当前边的左右邻接面
def get_sequence_faces(edge1, face1, face2) 
  edge_vex_array = Array.new()
  edge_vex_array = edge1.vertices
  
  vex1 = edge_vex_array[0]
  vex2 = edge_vex_array[1]
  
  #有向边方向为vex1->vex2
  
  #获取三角形另一个顶点
  face1_vex_arr = Array.new()
  face1_vex_arr = face1.vertices
  face1_vex_arr.delete(vex1)
  face1_vex_arr.delete(vex2)
  
  face2_vex_arr = Array.new()
  face2_vex_arr = face2.vertices
  face2_vex_arr.delete(vex1)
  face2_vex_arr.delete(vex2)
  
  face1_vex = face1_vex_arr[0]
  face2_vex = face2_vex_arr[0]
  
  point1 = vex1.position
  point2 = vex2.position
  
  face1_point = face1_vex.position
  face2_point = face2_vex.position
  
  #三个向量
  vec = Geom::Vector3d.new(point1, point2)
  vec1 = Geom::Vector3d.new(point2, face1_point)
  vec2 = Geom::Vector3d.new(point2, face2_point)
  
  face1_vec = vec * vec1
  face2_vec = vec * vec2
  
  #面的法线方向
  normal1 = face1.normal
  normal2 = face2.normal
  
  #根据法线与叉乘向量的角度 判断面的左右方向 逆时针为左面 反之为右面
  angle1 = face1_vec.angle_between normal1
  
  if(angle1 >= 0 && angle1 < 0.01)
    #face1为左邻接面
    return vex1, vex2, face1_vex, face2_vex, face1, face2 
  else
    #face1为右邻接面
    return vex1, vex2, face2_vex, face1_vex, face2, face1
  end   
end

#创建插件，实现命令
toolbar_transform = UI::Toolbar.new 'Transform'

#创建命令（主函数）调用各函数
plugin = UI::Command.new('topo_transform'){ 
  # Default code, use or delete...
  mod = Sketchup.active_model # Open model
  ent = mod.entities # All entities in model
  sel = mod.selection # Current selection
  
  
  ########## 一、模型初步还原 ##########
  
  
  #存储读取的所有顶点信息
  all_vertices_array=Array.new()
  
  #打开excel文件
  #创建数组，存储顶点坐标信息
  #vex_array[i].x=worksheet.Range('a#{i+1}')['Value']
  excel = WIN32OLE::new('excel.Application')
  excel_file_path = UI.openpanel("选择 Excel 文件","","Excel Files|*.xlsx||")
  if excel_file_path
    puts "成功打开文件"
  else
    UI.messagebox("未选择excel文件")
  end
  
  #确定顶点数量
  line1 = 2
  while worksheet.Range("a#{line1}").value
    line1=line1+1
  end
  
  #读取坐标信息
  for i in (0..line1-3)
    all_vertices_array[i]=[worksheet.Range("b#{i+2}").value.m,worksheet.Range("c#{i+2}").value.m,worksheet.Range("d#{i+2}").value.m]#所有的顶点
  end
  
  last_vex = all_vertices_array[line1-3]
  
  #按照顶点顺序进行连接 获取初始的所有边线
  traversed_edges_array = Array.new()
  for i in(0..all_vertices_array.length-2)
    start_edge = ent.add_line(all_vertices_array[i],all_vertices_array[i+1])
    traversed_edges_array << start_edge
  end
  
  all_edges_array = traversed_edges_array

  #前三个顶点生成初始三角形
  firedge = ent.add_line(all_vertices_array[0], all_vertices_array[2])
  all_edges_array << firedge  
  ent.add_face(all_vertices_array[0], all_vertices_array[1], all_vertices_array[2])
  
  #第四个顶点与一、三顶点构成第二个三角形
  secedge = ent.add_line(all_vertices_array[0], all_vertices_array[3])
  all_edges_array << secedge  
  ent.add_face(all_vertices_array[0], all_vertices_array[2], all_vertices_array[3])

  #判断新生成的边(new_edge) 与 当前待连接边(now_edge)及下一条遍历边(next_edge)中哪一条相连接
  eum1 = 0
  eum2 = 3
  new_edge = secedge
  now_edge = traversed_edges_array[eum1]
  next_edge = traversed_edges_array[eum2]
  
  #初始顶点
  num1 = 0
  num2 = 3
  num3 = 1
  num4 = 4
  
  vex1 = all_vertices_array[num1]
  vex2 = all_vertices_array[num2]
  now_vex = all_vertices_array[num3]
  next_vex = all_vertices_array[num4]

  while(num4 != all_vertices_array.length)
    #new边与now边构成面
    new_edge1 = ent.add_line(vex2, now_vex)
    one_face = ent.add_face(vex1, vex2, now_vex)
    
    #new边与next边构成面
    next_edge1 = ent.add_line(next_vex, now_vex)
    two_face = ent.add_face(now_vex, vex2, next_vex)
    
    #不能直接获取面的法线方向 因为不知道面的方向是向内还是向外
    vec1_1 = Geom::Vector3d.new(vex1, vex2)
    vec1_2 = Geom::Vector3d.new(vex2, now_vex)
    
    vec2_1 = Geom::Vector3d.new(now_vex, vex2)
    vec2_2 = Geom::Vector3d.new(vex2, next_vex)
    
    oneface_normal = vec1_1 * vec1_2
    twoface_normal = vec2_1 * vec2_2
    
    angle1 = oneface_normal.angle_between twoface_normal
    
    refer_vector = Geom::Vector3d.new(vex2, now_vex)
    
    and_vector = oneface_normal * twoface_normal
    
    #反向则为凹面  同向则为凸面
    angle2 = and_vector.angle_between refer_vector
    
    #获取生成的面中的边线 删去新生成的边线
    one_edges_array = one_face.edges
    two_edges_array = two_face.edges
       
    #去除生成的俩个面
    one_face.erase!
    two_face.erase!
    
    one_edges_array.delete(new_edge)
    one_edges_array.delete(now_edge)
    two_edges_array.delete(new_edge1)
    two_edges_array.delete(next_edge)
    
    bool1 = 0
    for i in(0..all_edges_array.length-1)
      if(one_edges_array[0] == all_edges_array[i])
        bool1 = 1
      end
    end
    
    bool2 = 0
    for i in(0..all_edges_array.length-1)
      if(two_edges_array[0] == all_edges_array[i])
        bool2 = 1
      end
    end
    
    if(bool1 == 0)
      one_edges_array[0].erase!
    end
    
    if(bool2 == 0)
      two_edges_array[0].erase!
    end

    #平行或者凸面
    if(angle1 == 0 || angle2 < (Math::PI / 2))
      #puts '凸面'
      #new边与now边相连接构成三角形  更新new、 now边
      new_edge = ent.add_line(vex2, now_vex)
      all_edges_array << new_edge
      new_triangle = ent.add_face(vex1, vex2, now_vex)
      vex1 = now_vex
      num3 += 1
      now_vex = all_vertices_array[num3]
      eum1 += 1
      now_edge = traversed_edges_array[eum1]    
    else
      #puts '凹面'
      #去除连接的边  连接另外一条边
      #new_edge.erase
      new_edge = ent.add_line(vex1, next_vex)
      all_edges_array << new_edge
      new_triangle = ent.add_face(vex1, vex2, next_vex)
      vex2 = next_vex
      num4 += 1
      next_vex = all_vertices_array[num4]
      eum2 += 1
      next_edge = traversed_edges_array[eum2]
    end 
  end 
  puts '模型初步还原完成！'
  
  
  ########## 二、模型孔洞初步修复 ##########
  

  oneuse_edge_array = Array.new()
  #获取未遍历完全的边（仅被使用一次的边）
  for i in(0..all_edges_array.length-1)
    edge_face_array = all_edges_array[i].faces
    if(edge_face_array.length == 1)
      oneuse_edge_array << all_edges_array[i]
    end
  end
  
  noedge_array = Array.new()
  for i in(0..oneuse_edge_array.length-1)
    oneedge_vexs_array = Array.new()
    oneedge_vexs_array = oneuse_edge_array[i].vertices
   
    for j in(0..oneedge_vexs_array.length-1)
      if(oneedge_vexs_array[j].position == last_vex)
        noedge_array << oneuse_edge_array[i]
      end
    end
  end
  
  oneuse_edge_array.delete_if { |element| noedge_array.include?(element) }

  for i in(0..oneuse_edge_array.length-1)
    two_vex_arr = Array.new()
    two_vex_arr = oneuse_edge_array[i].vertices
    ent.add_face(two_vex_arr[0], two_vex_arr[1], last_vex)
  end
  puts '模型孔洞初步修复完成!'
  

  ########## 三、针对错误凹面进行修复 ##########  
  
  
  #遍历所有面 获取相邻的凹面
  num_max = 3 # 遍历所有面的次数 邻接面只有3个
  while(num_max > 0)
    num_max -= 1
    
    #遍历当前模型所有面
    concave_faces_array = Array.new()
    concave_faces_array = ent.grep(Sketchup::Face)

    for i in(0..concave_faces_array.length-1)
      if(concave_faces_array[i].nil?)
        next
      end
      
      #获取当前面的所有邻接面 判断凹凸关系
      concave_edges_array = Array.new()
      concave_edges_array = concave_faces_array[i].edges

      for j in(0..concave_edges_array.length-1)
        adjacent_faces_array = Array.new()
        adjacent_faces_array = concave_edges_array[j].faces
        
        if(adjacent_faces_array[0] == concave_faces_array[i])
          adjacent_face = adjacent_faces_array[1]
        else
          adjacent_face = adjacent_faces_array[0]
        end
        
        if(adjacent_face.nil?)
          next
        end
        
        #判断面与邻接面构成的角为凹还是凸
        #首先判断出哪个面为当前边的左邻接面  以左邻接面的法线向量 叉乘 右邻接面的法线向量
        vex11, vex22, left_vex, right_vex, left_face, right_face = get_sequence_faces(concave_edges_array[j], concave_faces_array[i], adjacent_face)
        
        #面的法线方向
        left_normal = left_face.normal
        right_normal = right_face.normal
        
        #判断邻接面是否共面
        lrangle = left_normal.angle_between right_normal
        
        start_point = vex11.position
        end_point = vex22.position

        #共边的方向向量
        comvec = Geom::Vector3d.new(start_point, end_point)
        
        face_normal = left_normal * right_normal
        
        face_angle1 = face_normal.angle_between comvec
        
        if(face_angle1 >= 0 && face_angle1 < 0.01 || lrangle >= 0 && lrangle < 0.01) #等于0
          #凸面 或者 共面
          next
        else
          #puts '凹面'
          #凹面  调整四个顶点之间的连接关系
          #先删去原来的共边
          concave_edges_array[j].erase!
          #连接新的面
          ent.add_face(left_vex, vex11, right_vex)
          ent.add_face(left_vex, right_vex, vex22)       
                 
          #同时，在原来面的数组中去除已经处理完成的邻接面
          concave_faces_array.delete_at(i)
          concave_faces_array.delete(adjacent_face)
        end 
      end
    end
  end
  puts '错误凹面进行修复完成!'


  ########## 四、多边形还原 ##########
  

  #遍历俩次 确保每个面都还原
  number = 2
  while(number > 0)
    number -= 1
    #三角面还原为多边形面
    #1、先获取所有的三角面
    all_faces_array = Array.new()
    all_faces_array = ent.grep(Sketchup::Face)

    #2、判断当前三角面的邻接面是否平行于当前面
    for i in(0..all_faces_array.length-1) 
      #获取邻接面
      if(all_faces_array[i] == nil)
        break
      else
        face_edges_array = Array.new()
        face_edges_array = all_faces_array[i].edges
      end

      for j in(0..face_edges_array.length-1)
        related_faces_array = Array.new()
        related_faces_array = face_edges_array[j].faces

        related_faces_array.delete(all_faces_array[i])

        face11 = all_faces_array[i]
        face22 = related_faces_array[0]
        
        if(face11 == nil)
          break
        end
        
        normal11 = face11.normal
        normal22 = face22.normal

        angle11 = normal11.angle_between normal22

        #3、平行：删去共边
        if(angle11 >= 0 && angle11 <= 0.000001)
          face_edges_array[j].erase!
          all_faces_array.delete(face22)
        end
      end
    end 
  end
  puts '多边形面还原完成！'
}

plugin.large_icon = "large.png"
plugin.small_icon = "small.png"
plugin.tooltip = "topology and position!"
plugin.status_bar_text = "get topology and position of vertex"
plugin.menu_text = "Transform"

toolbar_transform = toolbar_transform.add_item plugin
toolbar_transform.show
